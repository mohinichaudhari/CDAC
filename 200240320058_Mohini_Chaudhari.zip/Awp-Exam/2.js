function user()
{
   let inputcontain = document.getElementById("inputbox").value;

   let newelement =  document.getElementById("put");

   newelement.innerHTML=inputcontain;

   newelement.appendChild(newelement);

}